#!/bin/bash

echo "This is a basic example of a shell provisioner."
yum -y install screen vim

